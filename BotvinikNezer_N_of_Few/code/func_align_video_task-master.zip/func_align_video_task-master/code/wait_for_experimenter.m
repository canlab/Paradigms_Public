function [when] = wait_for_experimenter(win, cue_img)

cue_texture = Screen('MakeTexture',win, imread(cue_img));
Screen('DrawTexture',win,cue_texture,[]);
Screen('Flip', win);

pressed = 0;
while ~pressed   % keeps checking
    [responded, when, what] = KbCheck(-1); % When ‘deviceNumber’ is -1, KbCheck will query all keyboard devices and return their “merged state”
    if responded == 1
        input = KbName(what);
        if strcmp(input,'5%') 
            pressed = 1;
        end
    end
end

end
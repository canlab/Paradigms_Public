function func_align_video_view_rate_task = func_align_video_view_rate_task%(subjID, scanID)
% *************************************************************************
%   Program Name: self_other_task.m
%   Original Programmer: Luke Slipski @lslipski602@gmail.com
%   Created: August 11, 2019
%   Project: Spacetop
%   This program was designed to play videos associated with the Spatial
%   Topology grant and to collect 7 affective ratings at the end of each
%   video. The program takes in a subject's ID and a scan ID (1-4) and
%   shows a random order of a set of videos (1 set per scan).
%
%  Input:
%   1.) subjID -- A BIDS formatted subject identifier of the form
%   'spacetop_sub-001_tas-selfother_ses-03'
%   2.) scanID -- an integer value 1-4 to denote which of the 4 scans
%   included in the spatial topology grant are to be run.
% *************************************************************************

sub=sprintf('%03d',input('Subnum?'));
scanID=input('Session?');
startrun=input('Run?');
subjID=['spacetop_sub-' sub '_tas-videos_ses-' sprintf('%02d',scanID)];

% Clear the workspace and the screen
sca;
AssertOpenGL;

% for testing only, bypasses graphics sync tests which weren't working on
% windows dev PC. Should be set to 0 on stim PC. 0 also works fine on linux
% systems
Screen('Preference', 'SkipSyncTests', 1);

%----------------------------------------------------------------------
%                       Initialize Paths
%----------------------------------------------------------------------

% create data folder if it doesn't exist and a folder for the current
% participant
if ~exist([fileparts(pwd) '\data\',subjID],'dir')
    mkdir([fileparts(pwd) '\data\',subjID]);
end

% set base path. All other paths will reference subfolders within this path
global base_path;
base_path = fileparts(pwd);

% path for general paradigm folder
addpath(genpath(base_path));

% path for the video clips and randomized video orders in this experiment
video_path = fullfile(base_path, 'videos');

% determine which folder to look in for randomized videos and orders
if scanID == 1
    video_folder = 'videos1';
    order_folder = 'orders1';
    
    %     random_movie_order = [7	8	10	12	14	5	13	9	6	2	4	11	3	15	1]'; % for testing only, delete before production
    random_movie_order = [7	8	10	13	5	12	9	6	2	4	11	3	14	1]'; % for testing only, delete before production
    
    run_start = [1 5 9 13];
    run_stop = [4 8 12 length(random_movie_order)];
    
elseif scanID == 2
    video_folder = 'videos2';
    order_folder = 'orders2';
    random_movie_order = [6	4	10	12	14	2	7	13	8	11	9	16	3	5	1	15]'; % for testing only, delete before production
    run_start = [1 6 9 13];
    run_stop = [5 8 12 length(random_movie_order)];
    
elseif scanID == 3
    video_folder = 'videos3';
    order_folder = 'orders3';
    
    %     random_movie_order = [2	13	11	1	3	5	12	10	9	4	6	8	7]'; % for testing only, delete before production
    random_movie_order = [2	1 3 4 10 9 8 5	7 6]'; % for testing only, delete before production
    run_start = [1 5 8 ];
    run_stop = [4 7 length(random_movie_order)];
    
    
elseif scanID == 4
    video_folder = 'videos4';
    order_folder = 'orders4';
    
    random_movie_order = [5	7	1	2	4	8	6	3]'; % for testing only, delete before production
    run_start = [1 5 ];
    run_stop = [4 8];
else
    error('scanID must be a number 1 to 4 indicating which scan is being run')
end

random_movie_order=random_movie_order(run_start(startrun):end);
run_start=run_start(startrun:end);
run_stop=run_stop(startrun:end);

% path for helper scripts used in this experiment
code_path =fullfile(base_path, 'code');

% path for any cue images and image names
cue_path = fullfile(base_path, 'cues');
waiting_cue = 'waiting_cue.png';

% path for saving experiment log
sub_save_dir = fullfile(base_path, 'data',filesep,subjID);

%----------------------------------------------------------------------
%                       Window Parameters
%----------------------------------------------------------------------

global p
% Here we call some default settings  for setting up Psychtoolbox
PsychDefaultSetup(2);

% assign external screen number for the Screen we want to show participants
p.ptb.screenNumber = max(Screen('Screens'));

% Define black and white
p.ptb.white = WhiteIndex(p.ptb.screenNumber);
p.ptb.black = BlackIndex(p.ptb.screenNumber);

% Open an on screen window
[p.ptb.window, p.ptb.rect] = PsychImaging('OpenWindow', p.ptb.screenNumber, p.ptb.black);

% Get the size of the on screen window
[p.ptb.screenXpixels, p.ptb.screenYpixels] = Screen('WindowSize', p.ptb.window);

% remove cursor from screen
HideCursor;

% Query the frame duration
p.ptb.ifi = Screen('GetFlipInterval', p.ptb.window);

% Set up alpha-blending for smooth (anti-aliased) lines
Screen('BlendFunction', p.ptb.window, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');

% Setup the text type for the window
Screen('TextFont', p.ptb.window, 'Arial');
%Screen('TextFont', p.ptb.window, '-arabic-newspaper-medium-r-normal'); % for development on linux machine, where Arial isn't installed. Remove in production
Screen('TextSize', p.ptb.window, 20);

% Get the centre coordinate of the window
[p.ptb.xCenter, p.ptb.yCenter] = RectCenter(p.ptb.rect);


% Here we set the size of the arms of our fixation cross
p.fix.sizePix = 40;

% Now we set the coordinates (these are all relative to zero we will let
% the drawing routine center the cross in the center of our monitor for us)
p.fix.xCoords = [-p.fix.sizePix p.fix.sizePix 0 0];
p.fix.yCoords = [0 0 -p.fix.sizePix p.fix.sizePix];
p.fix.allCoords = [p.fix.xCoords; p.fix.yCoords];

% Set the line width for our fixation cross
p.fix.lineWidthPix = 4;

%----------------------------------------------------------------------
%                       Keyboard information
%----------------------------------------------------------------------

% Define the keyboard keys that are listened for. We will be using the escape key as
% an exit key and the space key as a skip-video key

KbName('UnifyKeyNames');
p.keys.space = KbName('space');
p.keys.esc = KbName('ESCAPE');
esc=p.keys.esc;
%----------------------------------------------------------------------
%                       Video Playback Setup
%----------------------------------------------------------------------
% looks for all videos in the current folder. Will cycle through
% alphabetically
moviename = '*.mp4';

% empty options for video Screen
shader = [];
pixelFormat = [];
maxThreads = [];

iteration = 0;
escape = 0;

% Use blocking wait for new frames by default:
blocking = 1;

% Default preload setting:
preloadsecs = [];

% Return full list of movie files from directory+pattern:
moviefiles=dir(fullfile(video_path,video_folder, moviename));
if isempty(moviefiles)
    fprintf('ERROR: No videos in directory\n')
else
    for i=1:size(moviefiles,1)
        moviefiles(i).name = [ video_path filesep video_folder filesep moviefiles(i).name ];
    end
end
moviecount = size(moviefiles,1);
PsychHomeDir('.cache');

% Playbackrate defaults to 1:
rate=1;

% Choose 16 pixel text size:
Screen('TextSize', p.ptb.window, 16);

%----------------------------------------------------------------------
%           Load Randomized Video Order for this Participant
%----------------------------------------------------------------------
subj_num = subjID(5:7);

% csv contains one column, which is Video_ID
%random_order_file = fullfile(random_order_path, strcat('task-videoviewrate_counterbalance_ver-', subj_num,'.csv'));
%random_order_table = readtable(random_order_file);
%random_movie_order = table2array(random_order_table(:,3));

random_order_table = table(random_movie_order); % testing only, delete before production

%----------------------------------------------------------------------
%                       Set Up Timing Variables for Saving
%----------------------------------------------------------------------
explog.date = date;
explog.subjID = subjID;
explog.scanID = scanID;
explog.movie_start = zeros(size(random_order_table,1),1);
explog.movie_end = zeros(size(random_order_table,1),1);
explog.rating_start = zeros(size(random_order_table,1),1);
explog.rating_decide_onset = zeros(size(random_order_table,1),1);
explog.decision_rt = zeros(size(random_order_table,1),1);

runnum=0;

%-------------------------------------------------------------------------------
%                            0. Experimental loop
%-------------------------------------------------------------------------------
try
    
    for trl = 1:length(random_movie_order)
        
        
        if scanID == 1
            
            %             random_movie_order = [7	8	10	12	14	5	13	9	6	2	4	11	3	15	1]'; % for testing only, delete before production
            %    random_movie_order = [7	8	10	13	5	12	9	6	2	4	11	3	14	1]'; % for testing only, delete before production
            
            run_start = [1 5 9 13];
            run_stop = [4 8 12 length(random_movie_order)];
            
            
            
        elseif scanID == 2
            
            % random_movie_order = [6	4	10	12	14	2	7	13	8	11	9	16	3	5	1	15]'; % for testing only, delete before production
            run_start = [1 6 9 13];
            run_stop = [5 8 12 length(random_movie_order)];
            
        elseif scanID == 3
            
            %             random_movie_order = [2	13	11	1	3	5	12	10	9	4	6	8	7]'; % for testing only, delete before production
            random_movie_order = [2	1 3 4 10 9 8 5	7 6]'; % for testing only, delete before production
            
            run_start = [1 5 8 ];
            run_stop = [4 7 length(random_movie_order)];
            
        elseif scanID == 4
            
            % random_movie_order = [5	7	1	2	4	8	6	3]'; % for testing only, delete before production
            run_start = [1 5 ];
            run_stop = [4 8];
        end
        
        
        if any(trl==run_start)
            
            runnum=runnum+1;
            
            
            % bring up screen and wait for scanner to send first trigger of '5'
            [first_pulse] = wait_for_experimenter(p.ptb.window, fullfile(cue_path, waiting_cue));
            explog.first_pulse = first_pulse;
        end
        
        
        
        %allows esc to exit psych toolbox
        if escape==2
            %break
        end
        
        % Counts through movies
        current_movie = moviefiles(random_movie_order(trl, :)).name;
        
        %-------------------------------------------------------------------------------
        %                                  2. Video (5s)
        %-------------------------------------------------------------------------------
        
        % Open movie file and retrieve basic info about movie:
        [movie movieduration fps imgw imgh] = Screen('OpenMovie', p.ptb.window, current_movie, [], preloadsecs, [], pixelFormat, maxThreads);
        totalframes=floor(fps*movieduration);
        fprintf('Movie: %s  : %f seconds duration, %f fps, w x h = %i x %i...\n', current_movie, movieduration, fps, imgw, imgh);
        
        i=0;
        
        % Start playback of movie. This will start
        % the realtime playback clock and playback of audio tracks, if any.
        % Play 'movie', at a playbackrate = 1, with endless loop=1 and
        % 1.0 == 100% audio volume.
        Screen('PlayMovie', movie, rate, 1, 1.0);
        explog.movie_start(trl) = GetSecs;
        
        % Plays movies while frame count is less than total frames
        while i<totalframes-1
            
            escape=0;
            [keyIsDown,secs,keyCode]=KbCheck;
            if (keyIsDown==1 && keyCode(esc))
                % Set the abort-demo flag.
                escape=2;
                % break;
            end
            
            % Spacebar to skip to next movie. CAN BE COMMENTED OUT
            %if (keyIsDown==1 && keyCode(space))
            % break;
            %end
            
            % Only perform video image fetch/drawing if playback is active
            % and the movie actually has a video track (imgw and imgh > 0):
            if ((abs(rate)>0) && (imgw>0) && (imgh>0))
                % Return next frame in movie, in sync with current playback
                % time and sound.
                % tex is either the positive texture handle or zero if no
                % new frame is ready yet in non-blocking mode (blocking == 0).
                % It is -1 if something went wrong and playback needs to be stopped:
                tex = Screen('GetMovieImage', p.ptb.window, movie, blocking);
                
                % Valid texture returned?
                if tex < 0
                    % No, and there won't be any in the future, due to some
                    % error. Abort playback loop:
                    %  break;
                end
                
                if tex == 0
                    % No new frame in polling wait (blocking == 0). Just sleep
                    % a bit and then retry.
                    WaitSecs('YieldSecs', 0.005);
                    continue;
                end
                
                % Draw the new texture immediately to screen:
                Screen('DrawTexture', p.ptb.window, tex, [], [], [], [], [], [], shader);
                
                % Update display:
                Screen('Flip', p.ptb.window);
                
                % Release texture:
                Screen('Close', tex);
                
                % Framecounter:
                i=i+1;
                
            end % end if statement for grabbing next frame
        end % end while statement for playing until no more frames exist
        
        %get movie playback end time
        explog.movie_end(trl) = GetSecs;
        
        Screen('Flip', p.ptb.window);
        KbReleaseWait;
        
        % Done. Stop playback:
        Screen('PlayMovie', movie, 0);
        
        % Close movie object:
        Screen('CloseMovie', movie);
        
        % if escape is pressed during video, exit
        if escape==2
            %break
        end
        
        %-------------------------------------------------------------------------------
        %                             3. Judgement rating (5s)
        %-------------------------------------------------------------------------------
        [ratings, times, RT] = rating_scale(p);
        explog.rating.ratings{trl} = ratings;
        explog.rating.times{trl} = times;
        explog.rating.RT{trl} = RT;
        %explog.rating_start(trl) = rating_onset;
        %explog.rating_decide_onset(trl) = buttonPressOnset;
        %explog.rating_trajectory{trl,1} = trajectory;
        %explog.decision_rt(trl) = RT;
        
        
        
        if any(trl==run_stop);
            %-------------------------------------------------------------------------------
            %                                   save parameter
            %-------------------------------------------------------------------------------
            save_file_name = fullfile(sub_save_dir,strcat('explog','sub_', subjID,'run_' ,num2str(runnum) ,'.mat'));
            save(save_file_name, 'explog');
            %Screen('CloseAll')
            
        end
        
    end
    
catch e
    display(e.message);
    Screen('CloseAll');
end

Screen('CloseAll')





